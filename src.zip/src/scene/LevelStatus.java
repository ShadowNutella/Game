package scene;

public enum LevelStatus {
    PLAYING,
    WON,
    LOST
}
